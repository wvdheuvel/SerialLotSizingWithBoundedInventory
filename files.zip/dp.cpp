#include <iostream>
#include <cmath>
#include "arrays.h"

using namespace std;

void cumDemands(int n, double *demand, double **matrix);
void cumHolding(int m, int n, double **cumD, double **h, double **cumH);
void costZWtrees(int m, int n, double *d, double **K, double **p, double **h, double ****cost);
void BottleneckTrees(int m, int n, int L, double *d, double **K, double **p, double **h, double U, double ****costBN);

double ConcatenateRN(int m, int n, int L, double *d, double **K, double **p, double **h, double U)
{	double opt=-1.0, tmpCst, minCst;
	double inf=pow(10.0,10.0);
	
	double **f;				//f[b][t] min cost to satisfy demands up till t using bottleneck periods up till b
	double ****costBN;		//costs[j1][j2][t1][t2] min cost to satisfy demands [t1,t2] through bottleneck periods [j1,j2]
	SetDim2Dbl(f,n+1,n+1);	
	SetDim4Dbl(costBN,n,n,n,n);
	BottleneckTrees(m,n,L,d,K,p,h,U,costBN);

	// Initialize
	f[0][0]=0;
	for (int t=1; t<=n; t++)
		f[0][t]=inf;

	// General DP
	for (int t2=1; t2<=n; t2++)
	{	for (int b2=1; b2<=t2; b2++)
		{	minCst=inf;
			for (int t1=1; t1<=t2; t1++)
			{	for (int b1=1; (b1<=t1)&&(b1<=b2); b1++)
				{	tmpCst=f[b1-1][t1-1]+costBN[b1-1][b2-1][t1-1][t2-1];
					if (tmpCst<minCst)
						minCst=tmpCst;
				}
			}
			f[b2][t2]=minCst;
		}
	}

	// Find minimum
	opt=inf;
	for (int b=1; b<=n; b++)
	{	if (f[b][n]<opt)
			opt=f[b][n];
	}

	DeleteDim2Dbl(f,n+1,n+1);
	DeleteDim4Dbl(costBN,n,n,n,n);
	return opt;
}

void BottleneckTrees(int m, int n, int L, double *d, double **K, double **p, double **h, double U, double ****costBN)
{	// define 4-dim cost array
	double inf, eps, **cumD, tmpCst, minCst;
	double ****costZW; //costs[i][j][t1][t2] min cost to satisfy demands in [t1,t2] from node (i,j)	
	SetDim2Dbl(cumD,n,n);	// cumulative demands
	SetDim4Dbl(costZW,m+1,n,n,n); // add dummy level 0 for convenience	
	
	// precomputation
	inf=pow(10.0,10.0);
	eps=pow(10.0,-5.0);
	cumDemands(n,d,cumD);
	costZWtrees(m,n,d,K,p,h,costZW);
	cout << costZW[0][0][0][n-1] << endl;

	// Initialization
	for (int b=0;b<n;b++)
	{	for (int t1=b;t1<n;t1++)	
		{	for (int t2=t1;t2<n;t2++)
			{	if(cumD[t1][t2]<=U+eps)
					costBN[b][b][t1][t2]=K[L][b]+p[L][b]*cumD[t1][t2]+costZW[L+1][b][t1][t2];
				else
					costBN[b][b][t1][t2]=inf;
			}
		}
	}

	// General DP
	for (int t2=0; t2<n; t2++)
	{	for (int b2=0; b2<=t2; b2++)	
		{	for (int b1=b2-1; b1>=0; b1--)
			{	for(int t1=t2; t1>=b1; t1--)
				{	if(cumD[t1][t2]<=U+eps)
					{	minCst=h[L-1][b1]*cumD[t1][t2]+costBN[b1+1][b2][t1][t2];
						for (int t=t1; t<=t2-1; t++)
						{	tmpCst=K[L][b1]+p[L][b1]*cumD[t1][t2]+costZW[L+1][b1][t1][t];
							tmpCst+=h[L-1][b1]*cumD[t+1][t2]+costBN[b1+1][b2][t+1][t2];
							if (tmpCst<minCst)
								minCst=tmpCst;
						}
						costBN[b1][b2][t1][t2]=minCst;
					}	
					else
						costBN[b1][b2][t1][t2]=inf;
				}
			}
		}
	}	

	DeleteDim4Dbl(costZW,m+1,n,n,n);		
	DeleteDim2Dbl(cumD,n,n);
}

void costZWtrees(int m, int n, double *d, double **K, double **p, double **h, double ****cost)
{	// define variables	
	double tmpCost, minCost, opt;	
	double **cumD, **cumH;
	SetDim2Dbl(cumD,n,n);	// cumulative demands
	SetDim2Dbl(cumH,n,n);	// cumulative holding cost
	cumDemands(n,d,cumD);
	cumHolding(m,n,cumD,h,cumH);	

	// initialize cost at retailer level
	for (int t1=0;t1<n;t1++)	
	{	for (int t2=t1;t2<n;t2++)
		{	cost[m][t1][t1][t2]=cumH[t1][t2];
			for (int j=t1-1;j>=0;j--)
			{	cost[m][j][t1][t2]=h[m-1][j]*cumD[t1][t2]+cost[m][j+1][t1][t2];
			}
		}
	}

	// initialize cost at last period
	for (int i=m-1;i>=0;i--)	
	{	cost[i][n-1][n-1][n-1]=cost[i+1][n-1][n-1][n-1]+K[i][n-1]+p[i][n-1]*d[n-1];
	}

	// apply general DP
	for (int i=m-1;i>=0;i--)
	{	for (int j=n-2;j>=0;j--)
		{	for (int t1=j;t1<n;t1++)	
			{	for (int t2=t1;t2<n;t2++)
				{	// special case: production flow only 
					minCost=K[i][j]+p[i][j]*cumD[t1][t2]+cost[i+1][j][t1][t2];
					
					// special case: inventory flow only
					if (t1>j) // otherwise not possible
					{	if (i==0) //dummy level
							tmpCost=cost[i][j+1][t1][t2];
						else
							tmpCost=h[i-1][j]*cumD[t1][t2]+cost[i][j+1][t1][t2];

						if (tmpCost<minCost)
							minCost=tmpCost;
					}

					// production and inventory flow
					for (int t=t1; t<t2; t++)
					{	tmpCost=K[i][j]+p[i][j]*cumD[t1][t]+cost[i+1][j][t1][t];
						if (i==0) //dummy level
							tmpCost+=cost[i][j+1][t+1][t2];
						else
							tmpCost+=h[i-1][j]*cumD[t+1][t2]+cost[i][j+1][t+1][t2];

						if (tmpCost<minCost)
							minCost=tmpCost;
					}

					if (minCost<0)
					{	cout << "Error: in DP" << endl;
						cin >> tmpCost;
					}
					cost[i][j][t1][t2]=minCost;

				}
			}				
		}
	}

	opt=cost[0][0][0][n-1];

	DeleteDim2Dbl(cumD,n,n);
	DeleteDim2Dbl(cumH,n,n);	
}