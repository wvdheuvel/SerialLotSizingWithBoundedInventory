#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <math.h>
#include "randomc.h"
#include "arrays.h"
#include <ctime>

void DataRnd(int m, int n, int L, double *d, double **K, double **p, double **h, double &U, TRandomMersenne &ran);
void CplexMLS(int m, int n, int L, double *d, double **K, double **p, double **h, double U, bool &interest, double &opt);
double solveZangwill(int m, int n, double *d, double **consCost, double **varCost, double **invCost);
double solveZangwill2(int m, int n, double *d, double **K, double **p, double **h);
void WriteData(int m, int n, int L, double *d, double **K, double **p, double **h, double U);
double ConcatenateRN(int m, int n, int L, double *d, double **K, double **p, double **h, double U);

using namespace std;

int main(int argc, char **argv) 
{
	// Definitions
	int i, j, L, m, n, tmpInt;	
	double *d, **K, **p, **h, U, optMIP=-1, optDP, optDP2, eps=0.00001, runtime; 
	long cnt=0;
	bool interest=0;
	TRandomMersenne ran = TRandomMersenne(142857);		
	clock_t t_start, t_end;
	//TRandomMersenne ran = TRandomMersenne(1);		

	// Initialize data
	m=5;	// number of levels
	n=10;	// number of periods
	L=1;	// bottleneck level

	d=new double[n];
	SetDim2Dbl(K,m,n);
	SetDim2Dbl(p,m,n);
	SetDim2Dbl(h,m,n);
	
	do
	{	//Generate data
		DataRnd(m,n,L,d,K,p,h,U,ran);

		//Solve problem with Cplex		
		CplexMLS(m,n,L,d,K,p,h,U,interest,optMIP);
		
		//Solve problem with Zangwill's DP
		/*t_start = clock();				
		optDP=solveZangwill(m,n,d,K,p,h);
		t_end = clock();		
		runtime = 1.0*(t_end - t_start)/CLOCKS_PER_SEC;
		cout << "Running time (s) DP1: " << runtime << endl;*/

		//Solve problem with Zangwill's DP
		t_start = clock();				
		optDP2=solveZangwill2(m,n,d,K,p,h);
		t_end = clock();		
		runtime = 1.0*(t_end - t_start)/CLOCKS_PER_SEC;
		cout << "Running time (s) DP2: " << runtime << endl;

		//Apply general DP
		optDP=ConcatenateRN(m,n,L,d,K,p,h,U);

		/*if (abs(optMIP-optDP2)>eps)
		{	cout << "Error: MIP vs DP" << endl;
			cin >> tmpInt;
		}*/
		
		cnt++;

		if (interest)
			WriteData(m,n,L,d,K,p,h,U);
	} 
	while(m>0);
	//cnt = 16 geeft interessante instantie

	// delete arrays
	delete[] d;
	DeleteDim2Dbl(K,m,n);
	DeleteDim2Dbl(p,m,n);
	DeleteDim2Dbl(h,m,n);
					
	cin >> i;
	return 0;
}